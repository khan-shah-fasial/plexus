<main>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <h3>Dashboard</h3><hr>
             <div class="row">

               <div class="col-lg-3">
                  <div class="card mb-3 progress-banner">
                     <div class="card-body justify-content-between d-flex flex-row align-items-center">
                        <div>
                           <div>
                              <a href="<?php echo base_url().'career_details'?>"><p class="lead text-white">Career</p></a>
                           </div>
                        </div>
                        <div>
                        </div>
                     </div>
                  </div>
               </div>
               
            </div>
            
         </div>
      </div>
   </div>
</main>